
package gisapplicatio;

import static gisapplicatio.Geometry.MULTIPOINT;
import java.sql.SQLException;

public class MultiPoint extends PointComposedGeom {
    /* JDK 1.5 Serialization */
    private static final long serialVersionUID = 0x100;

    public MultiPoint() {
        super(MULTIPOINT);
    }

    public MultiPoint(Point[] points) {
        super(MULTIPOINT, points);
    }

    public MultiPoint(String value) throws SQLException {
        this(value, false);
    }

    protected MultiPoint(String value, boolean haveM) throws SQLException {
        super(MULTIPOINT, value, haveM);
    }
}
