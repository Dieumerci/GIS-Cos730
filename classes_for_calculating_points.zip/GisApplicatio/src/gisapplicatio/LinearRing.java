package gisapplicatio;

import static gisapplicatio.Geometry.LINEARRING;
import java.sql.SQLException;
import java.util.List;


/**
 * This represents the LinearRing GIS datatype. This type is used to construct
 * the polygon types, but is not stored or retrieved directly from the database.
 */
public class LinearRing extends PointComposedGeom {
    /* JDK 1.5 Serialization */
    private static final long serialVersionUID = 0x100;
    private int dimension;
    private boolean haveMeasure;

    public LinearRing(Point[] points) {
        super(LINEARRING, points);
    }

    /**
     * This is called to construct a LinearRing from the PostGIS string
     * representation of a ring.
     * 
     * @param value Definition of this ring in the PostGIS string format.
     * @throws SQLException when a SQLException occurs
     */
    public LinearRing(String value) throws SQLException {
        this(value, false);
    }

    /**
     * @param value The text representation of this LinearRing
     * @param haveM Hint whether we have a measure. This is given to us by other
     *            "parent" Polygon, and is passed further to our parent.
     * @throws SQLException when a SQLException occurs
     */

    protected LinearRing(String value, boolean haveM) throws SQLException {
        super(LINEARRING);
        String valueNoParans = GeometryTokenizer.removeLeadingAndTrailingStrings(value.trim(), "(", ")");
        List<String> tokens = GeometryTokenizer.tokenize(valueNoParans, ',');
        int npoints = tokens.size();
        Point[] points = new Point[npoints];
        for (int p = 0; p < npoints; p++) {
            points[p] = new Point(tokens.get(p), haveM);
        }
        this.dimension = points[0].dimension;
        // fetch haveMeasure from subpoint because haveM does only work with
        // 2d+M, not with 3d+M geometries
        this.haveMeasure = points[0].haveMeasure;
        this.subgeomss = points;
    }

}