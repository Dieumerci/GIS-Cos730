package gisapplicatio;

/**
 *
 * @author Dieumerci
 */
class PGgeometry {

    static Geometry geomFromString(String token, boolean haveM) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
}
