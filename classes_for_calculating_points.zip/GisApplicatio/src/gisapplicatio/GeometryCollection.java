package gisapplicatio;

import static gisapplicatio.Geometry.GEOMETRYCOLLECTION;
import java.sql.SQLException;


public class GeometryCollection extends ComposedGeom {
    /* JDK 1.5 Serialization */
    private static final long serialVersionUID = 0x100;

    public static final String GeoCollID = "GEOMETRYCOLLECTION";
    private Object[] subgeoms;

    public GeometryCollection() {
        super(GEOMETRYCOLLECTION);
    }

    public GeometryCollection(Geometry[] geoms) {
        super(GEOMETRYCOLLECTION, geoms);
    }

    public GeometryCollection(String value) throws SQLException {
        this(value, false);
    }

    public GeometryCollection(String value, boolean haveM) throws SQLException {
        super(GEOMETRYCOLLECTION, value, haveM);
    }

    protected Geometry[] createSubGeomArray(int ngeoms) {
        return new Geometry[ngeoms];
    }

    @Override
    protected Geometry createSubGeomInstance(String token, boolean haveM) throws SQLException {
        return PGgeometry.geomFromString(token, haveM);
    }

    @Override
    protected void innerWKT(StringBuffer SB) {
       // subgeoms[0].outerWKT(SB, true);
        for (int i = 1; i < subgeoms.length; i++) {
            SB.append(',');
          //  subgeoms[i].outerWKT(SB, true);
        }
    }

    public Geometry[] getGeometries() {
        return (Geometry[]) subgeoms;
    }
}
