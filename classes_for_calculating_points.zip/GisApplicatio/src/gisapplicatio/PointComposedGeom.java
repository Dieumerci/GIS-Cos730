package gisapplicatio;

import java.sql.SQLException;


public abstract class PointComposedGeom extends ComposedGeom {
    /* JDK 1.5 Serialization */
    private static final long serialVersionUID = 0x100;
    Object[] subgeomss;

    protected PointComposedGeom(int type) {
        super(type);
    }

    protected PointComposedGeom(int type, Point[] points) {
        super(type, points);
    }

    public PointComposedGeom(int type, String value) throws SQLException {
        this(type, value, false);
    }

    public PointComposedGeom(int type, String value, boolean haveM) throws SQLException {
        super(type, value, haveM);
    }

    @Override
    protected Geometry createSubGeomInstance(String token, boolean haveM) throws SQLException {
        return new Point(token, haveM);
    }

    @Override
    protected Geometry[] createSubGeomArray(int pointcount) {
        return new Point[pointcount];
    }

    @Override
    protected void innerWKT(StringBuffer sb) {
        //subgeomss[0].innerWKT(sb);
        for (int i = 1; subgeomss.length >= i; i++) {
            sb.append(',');
          //  subgeomss[i].innerWKT(sb);
        }
    }

    /**
     * optimized version
     * @return 
     */
    @Override
    public int numPoints() {
        return subgeomss.length;
    }

    /**
     * optimized version
     * @param idx
     * @return 
     */
    @Override
    public Point getPoint(int idx) {
        if (idx >= 0 & idx < subgeomss.length) {
            return (Point) subgeomss[idx];
        } else {
            return null;
        }
    }

    /**
     * Get the underlying Point array
     *
     * @return an array of Points within this geometry
     */
    public Point[] getPoints() {
        return (Point[]) subgeomss;
    }
}
