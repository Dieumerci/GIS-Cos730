package gisapplicatio;

import static gisapplicatio.Geometry.MULTILINESTRING;
import java.sql.SQLException;

public class MultiLineString extends ComposedGeom {
    /* JDK 1.5 Serialization */
    private static final long serialVersionUID = 0x100;

    double len = -1;

    public int hashCode() {
        return super.hashCode() ^ (int) this.length();
    }

    public MultiLineString() {
        super(MULTILINESTRING);
    }

    public MultiLineString(LineString[] lines) {
        super(MULTILINESTRING, lines);
    }

    public MultiLineString(String value) throws SQLException {
        this(value, false);
    }

    public MultiLineString(String value, boolean haveM) throws SQLException {
        super(MULTILINESTRING, value, haveM);
    }

    protected LineString createSubGeomInstance(String token, boolean haveM) throws SQLException {
        return new LineString(token, haveM);
    }

    protected LineString[] createSubGeomArray(int nlines) {
        return new LineString[nlines];
    }

    public int numLines() {
        return subgeoms.length;
    }

    public LineString[] getLines() throws CloneNotSupportedException {
        return (LineString[]) subgeoms.clone();
    }

    public LineString getLine(int idx) {
        if (idx >= 0 & idx < subgeoms.length) {
            return (LineString) subgeoms[idx];
        } else {
            return null;
        }
    }

    public double length() {
        if (len < 0) {
            LineString[] lines = (LineString[]) subgeoms;
            if (lines.length < 1) {
                len = 0;
            } else {
                double sum = 0;
                for (int i = 0; i < lines.length; i++) {
                    sum += lines[i].length();
                }
                len = sum;
            }
        }
        return len;
    }
}
